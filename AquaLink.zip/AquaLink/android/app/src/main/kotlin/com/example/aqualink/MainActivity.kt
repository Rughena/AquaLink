package com.example.aqualink

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
