import 'package:aqualink/Ui/home/admin_home.dart';
import 'package:aqualink/Ui/place_order_screen.dart';
import 'package:aqualink/Ui/home/user_home.dart';
import 'package:aqualink/Ui/auth/view_models/login.dart';
import 'package:aqualink/views/water_order_screen.dart';
import 'package:aqualink/data/water_order_repository.dart';
import 'package:aqualink/viewmodels/water_order_viewmodel.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:aqualink/Ui/home/admin_orders_screen.dart';


import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AquaLink',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginPage(),
        '/adminHome': (context) => ChangeNotifierProvider(
          create: (_) => WaterOrderViewModel(
            WaterOrderRepository("https://684b115d165d05c5d35b67bb.mockapi.io"),
          ),
          child: const AdminHome(),
        ),
        '/userHome': (context) => const UserHome(),
        '/placeOrder': (context) => const PlaceOrderScreen(),
        '/mockOrders': (context) => ChangeNotifierProvider(
          create: (_) => WaterOrderViewModel(
            WaterOrderRepository("https://684b115d165d05c5d35b67bb.mockapi.io"),
          ),
          child: const WaterOrderScreen(),
        ),
        '/adminOrders': (context) => const AdminOrdersScreen(), // ✅ ADD THIS ROUTE
      },
    );
  }
}
