import 'package:flutter/material.dart';
import '../models/water_order_model.dart';
import '../data/water_order_repository.dart';

class WaterOrderViewModel extends ChangeNotifier {
  final WaterOrderRepository _repo;

  List<WaterOrder> _orders = [];
  List<WaterOrder> get orders => _orders;

  WaterOrderViewModel(this._repo);

  Future<void> fetchOrders() async {
    _orders = await _repo.fetchOrders();
    notifyListeners();
  }

  Future<void> addOrder(WaterOrder order) async {
    await _repo.addOrder(order);
    fetchOrders();
  }

  Future<void> updateOrder(String id, WaterOrder order) async {
    await _repo.updateOrder(id, order);
    fetchOrders();
  }

  Future<void> deleteOrder(String id) async {
    await _repo.deleteOrder(id);
    fetchOrders();
  }
}
