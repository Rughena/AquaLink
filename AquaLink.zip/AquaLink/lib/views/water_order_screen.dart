import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/water_order_viewmodel.dart';
import '../models/water_order_model.dart';

class WaterOrderScreen extends StatelessWidget {
  const WaterOrderScreen({super.key});

  @override
  Widget build(BuildContext ctx) {
    final vm = Provider.of<WaterOrderViewModel>(ctx);
    return Scaffold(
      appBar: AppBar(title: const Text("Water Orders (MockAPI)")),
      body: FutureBuilder(
        future: vm.fetchOrders(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (vm.orders.isEmpty) {
            return const Center(child: Text("No orders available"));
          }
          return ListView.builder(
            itemCount: vm.orders.length,
            itemBuilder: (_, i) {
              final o = vm.orders[i];
              return ListTile(
                title: Text("${o.userName}, ${o.liters}L"),
                subtitle: Text("${o.date}, ${o.location}"),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => vm.deleteOrder(o.id ?? ''),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => vm.addOrder(
          WaterOrder(
            id: '',
            userName: 'Test User',
            liters: '10',
            date: DateTime.now().toIso8601String().substring(0, 10),
            status: 'Pending',
            location: 'Lahore',
          ),
        ),
      ),
    );
  }
}
