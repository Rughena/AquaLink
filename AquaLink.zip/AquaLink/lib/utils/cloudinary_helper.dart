import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

Future<String?> uploadImageToCloudinary(XFile imageFile) async {
  const cloudName = 'dhhwvtrd3';
  const uploadPreset = 'flutter_unsigned';

  final uri = Uri.parse('https://api.cloudinary.com/v1_1/$cloudName/image/upload');

  final request = http.MultipartRequest('POST', uri)
    ..fields['upload_preset'] = uploadPreset
    ..files.add(await http.MultipartFile.fromPath('file', imageFile.path));

  final response = await request.send();
  final resStr = await response.stream.bytesToString();
  final data = jsonDecode(resStr);

  if (response.statusCode == 200) {
    return data['secure_url'];
  } else {
    print('Upload failed: ${data.toString()}');
    return null;
  }
}
