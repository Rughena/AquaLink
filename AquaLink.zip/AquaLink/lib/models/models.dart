import 'package:cloud_firestore/cloud_firestore.dart';

class WaterOrder {
  final String id;
  final String userId;
  final String userEmail;
  final int quantity;
  final String status;
  final DateTime orderedAt;

  WaterOrder({
    required this.id,
    required this.userId,
    required this.userEmail,
    required this.quantity,
    required this.status,
    required this.orderedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'userEmail': userEmail,
      'quantity': quantity,
      'status': status,
      'orderedAt': orderedAt,
    };
  }

  factory WaterOrder.fromMap(String id, Map<String, dynamic> map) {
    return WaterOrder(
      id: id,
      userId: map['userId'],
      userEmail: map['userEmail'],
      quantity: map['quantity'],
      status: map['status'],
      orderedAt: (map['orderedAt'] as Timestamp).toDate(),
    );
  }
}
