class WaterOrder {
  String? id;
  String userName;
  String liters;
  String date;
  String status;
  String location;

  WaterOrder({
    this.id,
    required this.userName,
    required this.liters,
    required this.date,
    required this.status,
    required this.location,
  });

  factory WaterOrder.fromJson(Map<String, dynamic> json) {
    return WaterOrder(
      id: json['id'],
      userName: json['userName'],
      liters: json['liters'],
      date: json['date'],
      status: json['status'],
      location: json['location'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userName': userName,
      'liters': liters,
      'date': date,
      'status': status,
      'location': location,
    };
  }
}
