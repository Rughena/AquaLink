// lib/services/order_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<void> placeOrder(int quantity) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) throw Exception("User not logged in");

  final orderData = {
    'userId': user.uid,
    'userEmail': user.email,
    'quantity': quantity,
    'status': 'pending',
    'orderedAt': FieldValue.serverTimestamp(),
  };

  await FirebaseFirestore.instance.collection('orders').add(orderData);
}
