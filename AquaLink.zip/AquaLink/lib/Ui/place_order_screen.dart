// 📄 place_order_screen.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PlaceOrderScreen extends StatefulWidget {
  const PlaceOrderScreen({super.key});

  @override
  State<PlaceOrderScreen> createState() => _PlaceOrderScreenState();
}

class _PlaceOrderScreenState extends State<PlaceOrderScreen> {
  final TextEditingController litersController = TextEditingController();
  String selectedFrequency = 'Daily';
  String selectedPaymentMethod = 'Cash';

  int totalCost = 0;
  final int pricePerLiter = 20; // adjust as you want

  void calculateCost() {
    final liters = int.tryParse(litersController.text) ?? 0;
    setState(() {
      totalCost = liters * pricePerLiter;
    });
  }

  Future<void> placeOrder() async {
    final liters = int.tryParse(litersController.text) ?? 0;
    if (liters <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter valid liters')),
      );
      return;
    }

    try {
      await FirebaseFirestore.instance.collection('orders').add({
        'userEmail': FirebaseAuth.instance.currentUser!.email,
        'liters': liters,
        'totalCost': totalCost,
        'frequency': selectedFrequency,
        'paymentMethod': selectedPaymentMethod,
        'status': 'pending',
        'timestamp': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Order placed successfully!')),
      );

      // Optionally clear fields:
      litersController.clear();
      setState(() {
        totalCost = 0;
        selectedFrequency = 'Daily';
        selectedPaymentMethod = 'Cash';
      });

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error placing order: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Place Order'),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Liters:', style: TextStyle(fontSize: 16)),
            TextField(
              controller: litersController,
              keyboardType: TextInputType.number,
              onChanged: (_) => calculateCost(),
              decoration: const InputDecoration(
                hintText: 'Enter liters',
              ),
            ),
            const SizedBox(height: 20),
            const Text('Delivery Frequency:', style: TextStyle(fontSize: 16)),
            DropdownButton<String>(
              value: selectedFrequency,
              onChanged: (value) {
                setState(() {
                  selectedFrequency = value!;
                });
              },
              items: ['Daily', 'Weekly', 'Monthly']
                  .map((freq) => DropdownMenuItem(
                value: freq,
                child: Text(freq),
              ))
                  .toList(),
            ),
            const SizedBox(height: 20),
            const Text('Payment Method:', style: TextStyle(fontSize: 16)),
            DropdownButton<String>(
              value: selectedPaymentMethod,
              onChanged: (value) {
                setState(() {
                  selectedPaymentMethod = value!;
                });
              },
              items: ['Cash', 'Card']
                  .map((method) => DropdownMenuItem(
                value: method,
                child: Text(method),
              ))
                  .toList(),
            ),
            const SizedBox(height: 20),
            Text('Total Cost: Rs $totalCost',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 40),
            Center(
              child: ElevatedButton(
                onPressed: placeOrder,
                child: const Text('Place Order'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
