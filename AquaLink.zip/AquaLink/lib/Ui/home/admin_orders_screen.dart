// lib/Ui/admin_orders_screen.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AdminOrdersScreen extends StatelessWidget {
  const AdminOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ordersStream = FirebaseFirestore.instance
        .collection('orders')
        .orderBy('timestamp', descending: true)
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Orders'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: ordersStream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final orders = snapshot.data?.docs ?? [];

          if (orders.isEmpty) {
            return const Center(child: Text('No orders found.'));
          }

          int totalLiters = 0;
          int totalRevenue = 0;

          for (final o in orders) {
            totalLiters += (o['liters'] as num?)?.toInt() ?? 0;
            totalRevenue += (o['totalCost'] as num?)?.toInt() ?? 0;
          }

          return Column(
            children: [
              Container(
                color: Colors.indigo.shade50,
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('Total Orders: ${orders.length}', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('Total Liters: $totalLiters L', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('Total Revenue: Rs $totalRevenue', style: const TextStyle(fontSize: 16)),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: orders.length,
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    final status = order['status'] ?? 'unknown';

                    return Card(
                      margin: const EdgeInsets.all(10),
                      child: ListTile(
                        title: Text('Liters: ${order['liters'] ?? '-'} | Total: Rs ${order['totalCost'] ?? '-'}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('User: ${order['userEmail'] ?? '-'}'),
                            Text('Frequency: ${order['frequency'] ?? '-'}'),
                            Text('Payment: ${order['paymentMethod'] ?? '-'}'),
                            Text('Status: $status'),
                          ],
                        ),
                        trailing: status == 'pending'
                            ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.check, color: Colors.green),
                              onPressed: () {
                                FirebaseFirestore.instance
                                    .collection('orders')
                                    .doc(order.id)
                                    .update({'status': 'approved'});
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, color: Colors.red),
                              onPressed: () {
                                FirebaseFirestore.instance
                                    .collection('orders')
                                    .doc(order.id)
                                    .update({'status': 'rejected'});
                              },
                            ),
                          ],
                        )
                            : null,
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
