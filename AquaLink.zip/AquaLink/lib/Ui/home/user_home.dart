import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:aqualink/utils/cloudinary_helper.dart';

class UserHome extends StatefulWidget {
  const UserHome({super.key});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  String email = '';
  String name = '';
  int waterSupplied = 0;
  int perLiterCost = 0;
  String imageUrl = '';

  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> fetchUserData() async {
    try {
      final uid = _auth.currentUser?.uid;
      if (uid != null) {
        final doc = await _firestore.collection('users').doc(uid).get();
        final data = doc.data();
        setState(() {
          email = data?['email'] ?? '';
          name = data?['name'] ?? 'User';
          waterSupplied = int.tryParse('${data?['watersupplied'] ?? 0}') ?? 0;
          perLiterCost = int.tryParse('${data?['perlitercost'] ?? 0}') ?? 0;
          imageUrl = data?['imageUrl'] ?? '';
        });
      }
    } catch (e) {
      debugPrint('Error loading user data: $e');
    }
  }

  Future<void> _uploadImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      final url = await uploadImageToCloudinary(picked);
      if (url != null) {
        final uid = _auth.currentUser?.uid;
        if (uid != null) {
          await _firestore.collection('users').doc(uid).update({
            'imageUrl': url,
          });
          setState(() {
            imageUrl = url;
          });
        }
      }
    }
  }

  Future<void> _showUpdateDialog() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    final doc = await _firestore.collection('users').doc(uid).get();
    final data = doc.data() ?? {};

    final nameController = TextEditingController(text: data['name'] ?? '');
    final waterController = TextEditingController(text: '${data['watersupplied'] ?? ''}');
    final costController = TextEditingController(text: '${data['perlitercost'] ?? ''}');

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Update Profile'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Name'),
                ),
                TextField(
                  controller: waterController,
                  decoration: const InputDecoration(labelText: 'Water Supplied (Liters)'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: costController,
                  decoration: const InputDecoration(labelText: 'Cost per Liter (Rs)'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                final name = nameController.text.trim();
                final waterSupplied = int.tryParse(waterController.text.trim()) ?? 0;
                final perLiterCost = int.tryParse(costController.text.trim()) ?? 0;

                await _firestore.collection('users').doc(uid).update({
                  'name': name,
                  'watersupplied': waterSupplied,
                  'perlitercost': perLiterCost,
                });

                Navigator.pop(context);
                fetchUserData();
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteProfile() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Delete'),
        content: const Text('Are you sure you want to delete your profile? This action is irreversible.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await _firestore.collection('users').doc(uid).delete();
        await _auth.currentUser?.delete();
        Navigator.of(context).pushReplacementNamed('/login');
      } catch (e) {
        debugPrint('Error deleting profile: $e');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Delete failed: $e')));
      }
    }
  }

  Future<void> _logout() async {
    await _auth.signOut();
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF6FF),
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        title: const Text('User Dashboard'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          elevation: 5,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.indigo.shade700,
                        backgroundImage: imageUrl.isNotEmpty ? NetworkImage(imageUrl) : null,
                        child: imageUrl.isEmpty
                            ? const Icon(Icons.person, size: 50, color: Colors.white)
                            : null,
                      ),
                      IconButton(
                        icon: const Icon(Icons.camera_alt, color: Colors.white),
                        onPressed: _uploadImage,
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  Text(email, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ListTile(
                    leading: const Icon(Icons.person),
                    title: Text('Name: $name'),
                  ),
                  ListTile(
                    leading: const Icon(Icons.water_drop),
                    title: Text('Water Supplied: $waterSupplied L'),
                  ),
                  ListTile(
                    leading: const Icon(Icons.attach_money),
                    title: Text('Cost per Liter: Rs $perLiterCost'),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: _showUpdateDialog,
                    icon: const Icon(Icons.edit),
                    label: const Text('Update Profile'),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: _deleteProfile,
                    icon: const Icon(Icons.delete),
                    label: const Text('Delete Profile'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: _logout,
                    icon: const Icon(Icons.logout),
                    label: const Text('Logout'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
