import 'package:aqualink/data/order_repository.dart';
import 'package:aqualink/models/models.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';


class OrderWaterScreen extends StatefulWidget {
  const OrderWaterScreen({Key? key}) : super(key: key);

  @override
  State<OrderWaterScreen> createState() => _OrderWaterScreenState();
}

class _OrderWaterScreenState extends State<OrderWaterScreen> {
  final TextEditingController quantityController = TextEditingController();
  final OrderRepository _orderRepo = OrderRepository();

  void _placeOrder() async {
    final user = FirebaseAuth.instance.currentUser!;
    final int quantity = int.tryParse(quantityController.text) ?? 0;
    if (quantity <= 0) return;

    WaterOrder newOrder = WaterOrder(
      id: '',
      userId: user.uid,
      userEmail: user.email ?? '',
      quantity: quantity,
      status: 'pending',
      orderedAt: DateTime.now(),
    );

    await _orderRepo.placeOrder(newOrder);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Order placed successfully!")));
    quantityController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Order Water")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: quantityController,
              decoration: InputDecoration(labelText: "Enter quantity in liters"),
              keyboardType: TextInputType.number,
            ),
            ElevatedButton(
              onPressed: _placeOrder,
              child: Text("Place Order"),
            ),
          ],
        ),
      ),
    );
  }
}
