import 'package:aqualink/data/order_repository.dart';
import 'package:aqualink/models/models.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserOrdersScreen extends StatelessWidget {
  final OrderRepository _repo = OrderRepository();

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: Text("My Orders")),
      body: StreamBuilder<List<WaterOrder>>(
        stream: _repo.getUserOrders(uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final orders = snapshot.data!;
          if (orders.isEmpty) return Center(child: Text("No orders yet."));

          return ListView.builder(
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              return ListTile(
                title: Text("${order.quantity} Liters"),
                subtitle: Text("Status: ${order.status}"),
                trailing: Text(order.orderedAt.toLocal().toString().split('.')[0]),
              );
            },
          );
        },
      ),
    );
  }
}
