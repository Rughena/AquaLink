import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthRepository {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Register with role (already done)
  Future<UserCredential?> registerUser(String email, String password, String role) async {
    try {
      UserCredential userCredential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      String collection = role == 'admin' ? 'admins' : 'users';

      await _firestore.collection(collection).doc(userCredential.user!.uid).set({
        'uid': userCredential.user!.uid,
        'email': email,
        'role': role,
        'createdAt': FieldValue.serverTimestamp(),
      });

      return userCredential;
    } catch (e) {
      print('Error in registerUser: $e');
      return null;
    }
  }

  // Login (already done)
  Future<UserCredential?> login(String email, String password) async {
    try {
      return await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      print('Login error: $e');
      return null;
    }
  }

  // ✅ NEW: Get role by UID
  Future<String?> getRoleByUid(String uid) async {
    var adminDoc = await _firestore.collection('admins').doc(uid).get();
    if (adminDoc.exists) return 'admin';

    var userDoc = await _firestore.collection('users').doc(uid).get();
    if (userDoc.exists) return 'user';

    return null;
  }

  // Logout
  Future<void> logout() async {
    await _firebaseAuth.signOut();
  }

  User? getCurrentUser() {
    return _firebaseAuth.currentUser;
  }

// CRUD Operations...
// [keep your CRUD code as is]
}
