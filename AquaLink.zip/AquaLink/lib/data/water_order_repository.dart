import 'package:http/http.dart' as http;
import 'dart:convert';

import '../models/water_order_model.dart';

class WaterOrderRepository {
  /// ✅ This will hold your MockAPI base URL
  late final String myMockApiUrl;

  /// ✅ Constructor: initialize with your base URL
  WaterOrderRepository(String url) {
    myMockApiUrl = '$url/waterorders'; // Entity endpoint
  }

  /// ✅ GET - Fetch all orders
  Future<List<WaterOrder>> fetchOrders() async {
    final res = await http.get(Uri.parse(myMockApiUrl));
    if (res.statusCode == 200) {
      return (json.decode(res.body) as List)
          .map((e) => WaterOrder.fromJson(e))
          .toList();
    } else {
      throw Exception('Failed to load orders');
    }
  }

  /// ✅ POST - Add a new order
  Future<void> addOrder(WaterOrder o) async {
    final res = await http.post(
      Uri.parse(myMockApiUrl),
      body: json.encode(o.toJson()),
      headers: {'Content-Type': 'application/json'},
    );
    if (res.statusCode != 201) {
      throw Exception('Failed to add order');
    }
  }

  /// ✅ PUT - Update an existing order by ID
  Future<void> updateOrder(String id, WaterOrder o) async {
    final res = await http.put(
      Uri.parse('$myMockApiUrl/$id'),
      body: json.encode(o.toJson()),
      headers: {'Content-Type': 'application/json'},
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to update order');
    }
  }

  /// ✅ DELETE - Delete an order by ID
  Future<void> deleteOrder(String id) async {
    final res = await http.delete(Uri.parse('$myMockApiUrl/$id'));
    if (res.statusCode != 200) {
      throw Exception('Failed to delete order');
    }
  }
}
