import 'package:aqualink/models/models.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class OrderRepository {
  final CollectionReference orderRef = FirebaseFirestore.instance.collection('orders');

  Future<void> placeOrder(WaterOrder order) async {
    await orderRef.add(order.toMap());
  }

  Stream<List<WaterOrder>> getUserOrders(String uid) {
    return orderRef
        .where('userId', isEqualTo: uid)
        .orderBy('orderedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => WaterOrder.fromMap(doc.id, doc.data() as Map<String, dynamic>))
        .toList());
  }

  Stream<List<WaterOrder>> getAllOrders() {
    return orderRef
        .orderBy('orderedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => WaterOrder.fromMap(doc.id, doc.data() as Map<String, dynamic>))
        .toList());
  }

  Future<void> updateOrderStatus(String orderId, String newStatus) async {
    await orderRef.doc(orderId).update({'status': newStatus});
  }
}
